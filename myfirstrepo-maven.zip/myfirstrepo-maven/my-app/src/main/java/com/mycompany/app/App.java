package com.mycompany.app;

/**
 * Hello world!, Welcome to Devops Training!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
